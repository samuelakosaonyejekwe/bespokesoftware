// Prompt understanding: experiment class, scientific domains, candidate models,
// quantities with units, and named locations. Entirely rule- and ontology-based so that it
// runs on-device with no network and gives the same reading of the same prompt every time.
import { DOMAINS, CLASS_CUES } from '../data/domains.js';
import { GAZETTEER, SITES, BODIES, CONSTANTS } from '../data/reference.js';
import { tryUnit, dimEq, isDimless, quantityName, D0 } from '../core/units.js';

const lc = s => String(s || '').toLowerCase();
const count = (text, phrase) => { let n = 0, i = 0; while ((i = text.indexOf(phrase, i)) !== -1) { const b = text[i - 1], a = text[i + phrase.length]; if (!(b && /[a-z0-9]/.test(b)) && !(a && /[a-z0-9]/.test(a) && phrase.length < 5)) n++; i += phrase.length; } return n; };

/** Experiment class scores and the cues that produced them. */
export function classifyClass(prompt, model) {
  const t = lc(prompt), score = { I: 0, II: 0, III: 0 }, cues = { I: [], II: [], III: [] };
  for (const k of ['I', 'II', 'III']) for (const cue of CLASS_CUES[k]) { const n = count(t, cue); if (n) { score[k] += n * (cue.includes(' ') ? 2 : 1); cues[k].push(cue); } }
  if (/\d/.test(t)) { score.I += 1; cues.I.push('numerical values present'); }
  if (model) (Array.isArray(model.klass) ? model.klass : [model.klass]).forEach((k, i) => { score[k] += i === 0 ? 4 : 2; cues[k].push(`matched model "${model.title}"`); });
  const order = Object.keys(score).sort((a, b) => score[b] - score[a]);
  const top = score[order[0]] || 0;
  const tags = order.filter(k => score[k] > 0 && score[k] >= Math.max(1, 0.45 * top));
  if (!tags.length) tags.push(model ? (Array.isArray(model.klass) ? model.klass[0] : model.klass) : 'I');
  return { primary: tags[0], tags, hybrid: tags.length > 1, score, cues };
}
export const CLASS_NAME = { I: 'Scientifically computable', II: 'Logically analysable', III: 'Speculative / counterfactual' };
export const CLASS_BLURB = {
  I: 'Described by explicit equations with justified inputs; produces numerical predictions that are only as reliable as the equations, data and validation behind them.',
  II: 'Built from propositions, definitions and inference; produces deductions, proofs, countermodels and conditional conclusions.',
  III: 'Explores invented or modified laws; produces conditional consequences that do not establish that those laws occur in nature.',
};

export function rankDomains(prompt) {
  const t = lc(prompt);
  return Object.entries(DOMAINS).map(([key, d]) => {
    let s = 0; const hits = [];
    d.kw.forEach(k => { const n = count(t, k); if (n) { s += n * (k.includes(' ') ? 3 : 1.5); hits.push(k); } });
    return { key, name: d.name, score: s, hits };
  }).filter(d => d.score > 0).sort((a, b) => b.score - a.score);
}

// ---- semantic index: every model is described by all of its own text, weighted by rarity of each word
const STOPWORDS = new Set('the a an of and or to in on at for by with as is are was were be been it its this that these those from into than then if so not no can could would should will may might do does did has have had how what which who why when where whether there their them they you your we our i me my about over under between through during each any all some more most much many very also such only just both either neither per via using used use find determine calculate compute given suppose imagine consider case model problem system value values result results'.split(' '));
const stem = w => w.replace(/-/g, '').replace(/(ations?|ization|isation)$/, 'at').replace(/(ies)$/, 'y').replace(/(ing|ed|ers?|es|s)$/, '').replace(/(al|ic|ity)$/, '').replace(/([b-df-hj-np-tv-z])\1$/, '$1').replace(/e$/, '');
const tokens = text => lc(text).replace(/[^a-z0-9/^\-]+/g, ' ').split(' ').filter(w => w.length > 1 && !STOPWORDS.has(w)).map(stem).filter(w => w.length > 1);
let INDEX = null;
function buildIndex(models) {
  const docs = models.map(m => { const tf = new Map(); const add = (t, w) => tokens(t).forEach(k => tf.set(k, (tf.get(k) || 0) + w)); add(m.title, 4); add(m.keywords.join(' '), 3); add(m.summary || '', 2); add([].concat(m.background || []).join(' '), 1); add((m.phenomena || []).join(' '), 2); add((m.inputs || []).map(i => i.name).join(' '), 1); return tf; });
  const df = new Map(); docs.forEach(tf => tf.forEach((_, k) => df.set(k, (df.get(k) || 0) + 1)));
  const idf = k => Math.log(1 + models.length / (df.get(k) || 0.5));
  const vecs = docs.map(tf => { const v = new Map(); let n = 0; tf.forEach((c, k) => { const x = (1 + Math.log(c)) * idf(k); v.set(k, x); n += x * x; }); return { v, n: Math.sqrt(n) || 1 }; });
  return { models, vecs, idf };
}
/** Cosine similarity between the prompt and each model's own description. */
export function semanticScores(prompt, models) {
  if (!INDEX || INDEX.models !== models) INDEX = buildIndex(models);
  const q = new Map(); tokens(prompt).forEach(k => q.set(k, (q.get(k) || 0) + 1));
  let qn = 0; q.forEach((c, k) => { const x = (1 + Math.log(c)) * INDEX.idf(k); q.set(k, x); qn += x * x; }); qn = Math.sqrt(qn) || 1;
  return INDEX.vecs.map(d => { let dot = 0; q.forEach((x, k) => { const y = d.v.get(k); if (y) dot += x * y; }); return dot / (qn * d.n); });
}
/** Share of the prompt's meaning-bearing words (weighted by rarity) that also occur in each model's description. */
export function coverage(prompt, models) {
  if (!INDEX || INDEX.models !== models) INDEX = buildIndex(models);
  const words = [...new Set(tokens(prompt).filter(w => !/^[\d.^/-]+$/.test(w) && w.length > 2))];
  const total = words.reduce((a, k) => a + INDEX.idf(k), 0) || 1;
  return INDEX.vecs.map(d => words.reduce((a, k) => a + (d.v.has(k) ? INDEX.idf(k) : 0), 0) / total);
}

/** Everyday phrasings that should reach a model but are not among its own keywords. */
const EXTRA_KEYWORDS = {
  'twin-paradox-time-dilation': ['twin travels', 'travelling twin', 'traveling twin', 'twins age', 'ages less', 'younger twin'],
  'transient-conduction-1d': ['suddenly heated', 'through a wall', 'heat a wall', 'heats up over time'],
  'pendulum-nonlinear': ['swinging weight', 'swing period'], 'projectile-drag': ['thrown ball', 'how far will it fly', 'fired at an angle'],
  'hydrate-formation-risk': ['ice-like plug', 'gas line freeze'], 'mass-spring-damper': ['shock absorber', 'bounces on a spring'],
};

export function rankModels(prompt, models, module) {
  const t = lc(prompt), doms = rankDomains(prompt), domScore = Object.fromEntries(doms.map(d => [d.key, d.score]));
  const sem = semanticScores(prompt, models), cov = coverage(prompt, models);
  const speculative = CLASS_CUES.III.some(c => count(t, c) > 0), logical = CLASS_CUES.II.some(c => count(t, c) > 0);
  return models.map((m, idx) => ({ m, idx })).filter(({ m }) => module === 1 || (Array.isArray(m.module) ? m.module.includes(2) : m.module === 2)).map(({ m, idx }) => {
    let s = 0; const hits = [];
    [...m.keywords, ...(EXTRA_KEYWORDS[m.id] || [])].forEach((k, i) => { const n = count(t, k); if (n) { const words = k.split(' ').length; s += (words * words * 3 + 1) * (1 + 0.5 / (i + 1)); hits.push(k); } });
    const ds = m.domains.reduce((a, d, i) => a + (domScore[d] || 0) * (i === 0 ? 0.5 : 0.2), 0);
    const title = lc(m.title).split(/\W+/).filter(w => w.length > 3 && t.includes(w)).length;
    const modBonus = module === 1 && (m.module === 1 || (Array.isArray(m.module) && m.module[0] === 1)) ? 1.15 : 1;
    const klass = [].concat(m.klass), hypo = !!m.hypothetical || klass[0] === 'III';
    // a counterfactual question should reach a counterfactual model, and an ordinary one should not
    const classFit = speculative ? (hypo ? 1.7 : klass.includes('III') ? 1.2 : 0.75) : hypo ? 0.7 : 1;
    const logicFit = logical && klass.includes('II') ? 1.25 : 1;
    const semantic = sem[idx] * 40;
    return { id: m.id, title: m.title, score: (s + ds + title + semantic) * modBonus * classFit * logicFit, kw: s, sem: sem[idx], cov: cov[idx], hits };
  }).filter(m => m.kw > 0 || m.sem > 0.06).sort((a, b) => b.score - a.score);
}

/** A match is trusted only when several of the model's own terms, a specific phrase, or its overall description agree with the prompt. */
export const strongMatch = r => !!r && r.score >= 4 && ((r.hits || []).length >= 2 || (r.hits || []).some(h => h.includes(' ')) || r.cov >= 0.42);

// ---------------------------------------------------------------- quantities
const WORD_UNITS = [
  [/\bdegrees?\s*(celsius|centigrade|c)\b/gi, '°C'], [/\bdegrees?\s*(fahrenheit|f)\b/gi, '°F'], [/\bdeg\s*c\b/gi, '°C'], [/\bkelvins?\b/gi, 'K'],
  [/\b(metres|meters|metre|meter)\s+per\s+second\s+squared\b/gi, 'm/s^2'], [/\b(metres|meters|metre|meter)\s+per\s+second\b/gi, 'm/s'],
  [/\b(kilometres|kilometers|kilometre|kilometer)\s+per\s+hour\b/gi, 'kph'], [/\bmiles\s+per\s+hour\b/gi, 'mph'],
  [/\bcubic\s+(metres|meters|metre|meter)\s+per\s+(hour|hr)\b/gi, 'm^3/h'], [/\bcubic\s+(metres|meters|metre|meter)\s+per\s+(second|sec)\b/gi, 'm^3/s'], [/\bcubic\s+(metres|meters|metre|meter)\s+per\s+day\b/gi, 'm^3/d'],
  [/\b(kilograms?|kg)\s+per\s+cubic\s+(metre|meter)\b/gi, 'kg/m^3'], [/\b(kilograms?|kg)\s+per\s+(second|sec)\b/gi, 'kg/s'],
  [/\bbarrels?\s+per\s+day\b/gi, 'bbl/d'], [/\bbpd\b/gi, 'bbl/d'], [/\bcubic\s+(metres|meters|metre|meter)\b/gi, 'm^3'], [/\bsquare\s+(metres|meters|metre|meter)\b/gi, 'm^2'],
  [/\b(kilometres|kilometers|kilometre|kilometer)\b/gi, 'km'], [/\b(millimetres|millimeters|millimetre|millimeter)\b/gi, 'mm'], [/\b(centimetres|centimeters|centimetre|centimeter)\b/gi, 'cm'],
  [/\b(micrometres|micrometers|micrometre|micrometer|microns?)\b/gi, 'um'], [/\b(nanometres|nanometers|nanometre|nanometer)\b/gi, 'nm'], [/\b(metres|meters|metre|meter)\b/gi, 'm'],
  [/\b(inches|inch)\b/gi, 'in'], [/\b(feet|foot)\b/gi, 'ft'], [/\bmiles?\b/gi, 'mi'], [/\blight[- ]years?\b/gi, 'ly'], [/\bastronomical units?\b/gi, 'AU'],
  [/\b(kilograms|kilogram|kilos)\b/gi, 'kg'], [/\b(grams|gram)\b/gi, 'g'], [/\b(tonnes|tonne|metric tons?)\b/gi, 't'], [/\bsolar mass(es)?\b/gi, 'Msun'], [/\bearth mass(es)?\b/gi, 'Mearth'],
  [/\b(seconds|second|secs)\b/gi, 's'], [/\b(milliseconds|millisecond)\b/gi, 'ms'], [/\b(microseconds|microsecond)\b/gi, 'us'], [/\b(nanoseconds|nanosecond)\b/gi, 'ns'],
  [/\b(minutes|minute|mins)\b/gi, 'min'], [/\b(hours|hour|hrs)\b/gi, 'h'], [/\b(days|day)\b/gi, 'd'], [/\b(years|year|yrs)\b/gi, 'yr'],
  [/\b(newtons|newton)\b/gi, 'N'], [/\b(kilonewtons|kilonewton)\b/gi, 'kN'], [/\b(pascals|pascal)\b/gi, 'Pa'], [/\b(megapascals|megapascal)\b/gi, 'MPa'], [/\b(kilopascals|kilopascal)\b/gi, 'kPa'], [/\b(gigapascals|gigapascal)\b/gi, 'GPa'],
  [/\bbars\b/gi, 'bar'], [/\batmospheres?\b/gi, 'atm'], [/\b(joules|joule)\b/gi, 'J'], [/\b(kilojoules|kilojoule)\b/gi, 'kJ'], [/\b(megajoules|megajoule)\b/gi, 'MJ'], [/\belectron[- ]?volts?\b/gi, 'eV'],
  [/\b(watts|watt)\b/gi, 'W'], [/\b(kilowatts|kilowatt)\b/gi, 'kW'], [/\b(megawatts|megawatt)\b/gi, 'MW'], [/\bhorsepower\b/gi, 'hp'],
  [/\b(volts|volt)\b/gi, 'V'], [/\b(kilovolts|kilovolt)\b/gi, 'kV'], [/\b(amperes|ampere|amps|amp)\b/gi, 'A'], [/\b(milliamps?|milliamperes?)\b/gi, 'mA'], [/\b(ohms)\b/gi, 'ohm'], [/\b(farads|farad)\b/gi, 'F'], [/\b(microfarads?)\b/gi, 'uF'],
  [/\b(henries|henry|henrys)\b/gi, 'H'], [/\b(teslas|tesla)\b/gi, 'T'], [/\b(coulombs|coulomb)\b/gi, 'C'],
  [/\b(hertz)\b/gi, 'Hz'], [/\b(kilohertz)\b/gi, 'kHz'], [/\b(megahertz)\b/gi, 'MHz'], [/\b(gigahertz)\b/gi, 'GHz'], [/\b(terahertz)\b/gi, 'THz'],
  [/\b(litres|liters|litre|liter)\b/gi, 'L'], [/\bpercent\b/gi, '%'], [/\b(degrees|degree)\b/gi, 'deg'], [/\bradians?\b/gi, 'rad'], [/\bknots\b/gi, 'kn'], [/\bcentipoise\b/gi, 'cP'],
  [/\bpsi[ag]?\b/gi, m => m.toLowerCase()], [/\bbarg\b/gi, 'barg'], [/\bbara\b/gi, 'bara'], [/\bmoles?\b/gi, 'mol'],
];
const SKIP_AFTER_IN = new Set(['the', 'a', 'an', 'this', 'that', 'each', 'every', 'order', 'total', 'which', 'both', 'all', 'its', 'their', 'our', 'my', 'one', 'two', 'such', 'any', 'some', 'water', 'air', 'vacuum', 'space', 'series', 'parallel', 'steady', 'deep']);
const BAD_UNITS = new Set(['a', 'at', 'as', 'is', 'd', 'h', 't', 'u', 'G', 'P', 'R', 'S', 'F', 'H', 'T', 'D_perm', 'l', 'rev', 'M_conc', 'g0', 'te', 'ha', 'oz', 'sec', 'cal', 'barn', 'kat', 'St', 'Np', 'lx', 'lm', 'sr', 'cd', 'Da', 'pc', 'au', 'Wb', 'ft', 'yd', 'mi', 'R', 'C', 'A', 'J', 'N', 'V', 'W', 'K', 'L', 'g', 's', 'm']);
const SAFE_SINGLE = new Set(['m', 's', 'g', 'K', 'N', 'V', 'W', 'J', 'A', 'L', 'C', 'T', 'F', 'H', 'h', 'd', 't', 'ft', 'mi']); // accepted only when directly attached to a number or clearly a unit context
const RELAXED = new Set(['m', 's', 'g', 'K', 'N', 'V', 'W', 'J', 'L', 'h', 'ft', 'mi']); // read as units whenever they follow a number
const MULT = { thousand: 1e3, million: 1e6, billion: 1e9, trillion: 1e12, hundred: 100, dozen: 12 };

/** Find numbers with (optional) units. Returns [{value, unit, si, dim, quantity, start, end, raw}]. */
export function extractQuantities(prompt) {
  let text = String(prompt);
  WORD_UNITS.forEach(([re, rep]) => { text = text.replace(re, m0 => (typeof rep === 'function' ? rep(m0) : rep)); });
  const out = [];
  const reNum = /(?<![A-Za-z_\d.])([-−–]?\d{1,3}(?:,\d{3})+(?:\.\d+)?|[-−–]?\d+\.?\d*(?:[eE][-+]?\d+)?|[-−–]?\.\d+)(?:\s*(?:×|x|\*)\s*10\s*\^?\s*([-−]?\d+))?/g;
  let m;
  while ((m = reNum.exec(text))) {
    let value = parseFloat(m[1].replace(/,/g, '').replace(/[−–]/g, '-'));
    // a leading dash right after a word is a hyphen or range, not a minus sign
    if (/^[-−–]/.test(m[1]) && /[A-Za-z0-9]$/.test(text.slice(0, m.index).trimEnd()) && !/[=(,:]\s*$/.test(text.slice(0, m.index))) value = Math.abs(value);
    if (m[2]) value *= Math.pow(10, parseInt(m[2].replace('−', '-'), 10));
    let end = m.index + m[0].length;
    let rest = text.slice(end);
    const mm = /^\s*(thousand|million|billion|trillion|hundred|dozen)\b/i.exec(rest);
    if (mm) { value *= MULT[mm[1].toLowerCase()]; end += mm[0].length; rest = text.slice(end); }
    // fraction of light speed: "0.8c", "0.8 c", "80% of the speed of light"
    const mc = /^\s?c\b(?!\w)/.exec(rest), mcp = /^\s*%\s*(?:of\s+)?(?:the\s+)?speed of light/i.exec(rest), mct = /^\s*(?:times\s+)?(?:the\s+)?speed of light/i.exec(rest);
    if ((mc && value < 10 && !/^\s?c\w/.test(rest)) || mcp || mct) {
      const frac = mcp ? value / 100 : value, len = (mc || mcp || mct)[0].length;
      out.push({ value: frac, unit: 'c', si: frac * CONSTANTS.c.value, dim: [0, 1, -1, 0, 0, 0, 0], quantity: 'velocity (fraction of light speed)', start: m.index, end: end + len, raw: text.slice(m.index, end + len), lightFraction: frac });
      reNum.lastIndex = end + len; continue;
    }
    const attached = !/^\s/.test(rest);
    const mu = /^\s{0,2}([A-Za-zµμΩ°%"][A-Za-z0-9µμΩ°%"^/.·*()\-]{0,14})/.exec(rest);
    let unit = '', u = null, ulen = 0;
    if (mu) {
      let cand = mu[1].replace(/[.,;:)]+$/, '');
      while (cand.length) {
        const tu = tryUnit(cand);
        if (tu && !/^\d/.test(cand)) {
          const single = !/[/^*·]/.test(cand);
          const after = lc(text.slice(end + mu[0].indexOf(cand) + cand.length).trim().split(/[\s,.;]/)[0]);
          let ok = true;
          if (single && BAD_UNITS.has(cand) && !RELAXED.has(cand) && !(SAFE_SINGLE.has(cand) && (attached || /^[\s]*$/.test(after) || !/^[a-z]{3,}$/.test(after) || ['long', 'wide', 'high', 'deep', 'thick', 'pipe', 'pipeline', 'diameter', 'tall', 'apart', 'away', 'above', 'below', 'per', 'of', 'and', 'at', 'in', 'to', 'for', 'from', 'with', 'by', 'is', 'on'].includes(after)))) ok = false;
          if (cand === 'in' && SKIP_AFTER_IN.has(after)) ok = false;
          if (cand === 'm' && /^(?:illion|ore|any)/.test(after)) ok = false;
          if (ok) { unit = cand; u = tu; ulen = mu[0].indexOf(cand) + cand.length; }
          break;
        }
        cand = cand.slice(0, -1);
      }
    }
    const si = u ? value * u.f + u.o : value;
    out.push({ value, unit, si, dim: u ? u.dim : D0, quantity: u ? quantityName(u.dim) : 'number', start: m.index, end: end + ulen, raw: text.slice(m.index, end + ulen).trim(), bare: !u });
    reNum.lastIndex = end + ulen;
  }
  return { text, items: out };
}

/** Assign extracted quantities to a model's inputs by dimension, nearby wording and plausibility of magnitude. */
export function mapQuantities(extracted, inputs) {
  const { text, items } = extracted, t = lc(text), used = new Set(), mapped = [];
  const cands = items.map((q, qi) => {
    const before = t.slice(Math.max(0, q.start - 70), q.start), after = t.slice(q.end, q.end + 45);
    const scores = inputs.map(inp => {
      const u = tryUnit(inp.unit);
      if (!u) return -Infinity;
      if (q.bare) { if (!isDimless(u.dim)) return -Infinity; }
      else if (!dimEq(u.dim, q.dim)) return -Infinity;
      if (inp.kind === 'numerical' || inp.kind === 'constant') return -Infinity;
      let s = 0, hit = false;
      const names = [...(inp.aliases || []), lc(inp.name)];
      for (const a of names) {
        const ib = before.lastIndexOf(a), ia = after.indexOf(a);
        if (ib !== -1) { s = Math.max(s, 6 - (before.length - ib - a.length) / 14 + a.length / 8); hit = true; }
        if (ia !== -1) { s = Math.max(s, 5 - ia / 10 + a.length / 8); hit = true; }
      }
      // plausibility: closeness of magnitude to the reference value and inside the declared range
      const ref = Math.abs(inp.si), val = Math.abs(q.si);
      if (ref > 0 && val > 0) s += Math.max(0, 2 - Math.abs(Math.log10(val / ref)));
      if (inp.rangeSI && (q.si < inp.rangeSI[0] * 0.5 || q.si > inp.rangeSI[1] * 2)) s -= 4;
      if ((q.bare || isDimless(q.dim)) && !hit) return -Infinity; // pure numbers and percentages need wording to anchor them
      return s;
    });
    return { qi, scores };
  });
  // greedy assignment, best score first
  const pairs = [];
  cands.forEach(c => c.scores.forEach((s, ii) => { if (s > -Infinity) pairs.push({ qi: c.qi, ii, s }); }));
  pairs.sort((a, b) => b.s - a.s);
  const qUsed = new Set();
  for (const p of pairs) {
    if (qUsed.has(p.qi) || used.has(p.ii) || p.s < 0.6) continue;
    const sameDim = inputs.filter(i => { const u = tryUnit(i.unit); return u && dimEq(u.dim, items[p.qi].dim) && i.kind !== 'numerical' && i.kind !== 'constant'; }).length;
    if (sameDim > 1 && p.s < 1.2) continue;
    qUsed.add(p.qi); used.add(p.ii);
    mapped.push({ q: items[p.qi], sym: inputs[p.ii].sym, confidence: Math.min(1, p.s / 6) });
  }
  return { mapped, unmapped: items.filter((_, i) => !qUsed.has(i)) };
}

// ---------------------------------------------------------------- places and bodies
export function locate(prompt) {
  const t = lc(prompt);
  const mll = /(-?\d{1,2}(?:\.\d+)?)\s*°?\s*([ns])\b[\s,]+(-?\d{1,3}(?:\.\d+)?)\s*°?\s*([ew])\b/i.exec(prompt) || /lat(?:itude)?\s*[:=]?\s*(-?\d{1,2}(?:\.\d+)?)()[\s,;]+lon(?:gitude)?\s*[:=]?\s*(-?\d{1,3}(?:\.\d+)?)()/i.exec(prompt);
  if (mll) {
    const lat = parseFloat(mll[1]) * (lc(mll[2]) === 's' ? -1 : 1), lon = parseFloat(mll[3]) * (lc(mll[4]) === 'w' ? -1 : 1);
    return { name: `${lat.toFixed(3)}°, ${lon.toFixed(3)}°`, lat, lon, source: 'Coordinates given in the prompt', marine: true };
  }
  let best = null;
  for (const g of GAZETTEER) for (const k of g.kw) { const i = t.indexOf(k); if (i !== -1 && (!best || k.length > best.k.length)) best = { g, k }; }
  if (best) return { ...best.g, source: 'Built-in gazetteer', marine: true, matched: best.k };
  for (const s of SITES) { const k = lc(s.name.split(',')[0].split('(')[0]).trim(); if (k.length > 3 && t.includes(k)) return { ...s, source: 'Built-in gazetteer', marine: false, matched: k }; }
  return null;
}
export function celestial(prompt) {
  const t = lc(prompt);
  return Object.entries(BODIES).filter(([k, b]) => new RegExp(`\\b${k}\\b`).test(t) || t.includes(lc(b.name) + "'s")).map(([k, b]) => ({ key: k, ...b }));
}

/** Short title for an investigation from the first clause of its prompt. */
export function titleFrom(prompt) {
  const s = String(prompt).trim().replace(/\s+/g, ' ');
  const first = s.split(/(?<=[.?!])\s/)[0];
  return (first.length > 72 ? first.slice(0, 69).replace(/\s+\S*$/, '') + '…' : first) || 'Untitled investigation';
}
